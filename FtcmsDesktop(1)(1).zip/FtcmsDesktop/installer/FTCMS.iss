; Inno Setup 6 script. Names are kept in English on purpose (ANSI-safe); the application itself is Persian.
[Setup]
AppId={{B7C6A3E2-5D4F-4C1A-9E8B-2F0A6D3C7E11}
AppName=FTCMS - Faculty Training Management
AppVersion=1.0.0
AppPublisher=Faculty Co-thinking Office, Bushehr University of Medical Sciences
DefaultDirName={autopf}\FTCMS
DefaultGroupName=FTCMS
OutputDir=output
OutputBaseFilename=FTCMS-Setup-1.0.0
SetupIconFile=..\FtcmsDesktop\Assets\app.ico
UninstallDisplayIcon={app}\FTCMS.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: checkedonce

[Files]
Source: "..\publish\FTCMS.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\FTCMS"; Filename: "{app}\FTCMS.exe"
Name: "{autodesktop}\FTCMS"; Filename: "{app}\FTCMS.exe"; Tasks: desktopicon

[Run]
; Allow the built-in verification page (QR target) to listen on the network, port 8080
Filename: "{sys}\netsh.exe"; Parameters: "http add urlacl url=http://+:8080/ sddl=D:(A;;GX;;;WD)"; Flags: runhidden
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""FTCMS Verify"" dir=in action=allow protocol=TCP localport=8080"; Flags: runhidden
Filename: "{app}\FTCMS.exe"; Description: "Launch FTCMS"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "http delete urlacl url=http://+:8080/"; Flags: runhidden; RunOnceId: "DelUrlAcl"
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""FTCMS Verify"""; Flags: runhidden; RunOnceId: "DelFwRule"
