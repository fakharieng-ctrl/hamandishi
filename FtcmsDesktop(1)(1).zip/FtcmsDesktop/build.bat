@echo off
setlocal
cd /d "%~dp0"

where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 8 SDK is not installed. Opening the download page...
  start https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)

echo === Building FTCMS (self-contained, single file) ===
dotnet publish FtcmsDesktop\FtcmsDesktop.csproj -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true ^
  -o publish
if errorlevel 1 (
  echo Build FAILED. Copy the error text above and send it for a fix.
  pause
  exit /b 1
)

set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" (
  echo === Creating installer ===
  "%ISCC%" installer\FTCMS.iss
  echo.
  echo Done. Installer: installer\output\FTCMS-Setup-1.0.0.exe
) else (
  echo.
  echo The program was built: publish\FTCMS.exe  ^(runs without installation^)
  echo To also create Setup.exe, install Inno Setup 6 from https://jrsoftware.org/isdl.php and run build.bat again.
)
pause
