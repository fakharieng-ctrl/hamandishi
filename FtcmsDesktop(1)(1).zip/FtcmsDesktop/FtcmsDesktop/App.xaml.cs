using System.IO;
using System.Windows;
using System.Windows.Threading;
using Ftcms.Data;
using Ftcms.Services;
using QuestPDF.Infrastructure;

namespace Ftcms;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += (s, a) =>
        {
            LogError(a.Exception);
            Msg.Error("خطای پیش‌بینی‌نشده رخ داد:\n" + a.Exception.Message);
            a.Handled = true;
        };

        try
        {
            QuestPDF.Settings.License = LicenseType.Community;
            Directory.CreateDirectory(Paths.Dir);
            SettingsStore.Load();

            using (var db = new AppDb()) db.Database.EnsureCreated();

            Fonts.Init();

            if (SettingsStore.Current.EnableServer)
            {
                try { VerifyServer.Start(SettingsStore.Current.Port); }
                catch (Exception ex) { LogError(ex); }   // نبود سرور استعلام مانع کار برنامه نیست
            }

            new MainWindow().Show();
        }
        catch (Exception ex)
        {
            LogError(ex);
            Msg.Error("برنامه شروع نشد:\n" + ex.Message);
            Shutdown();
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        VerifyServer.Stop();
        base.OnExit(e);
    }

    public static void LogError(Exception ex)
    {
        try { File.AppendAllText(Paths.ErrorLog, $"[{DateTime.Now:u}] {ex}\n\n"); } catch { }
    }
}
