using System.Windows;
using System.Windows.Input;
using Ftcms.Data;
using Ftcms.Services;
using Microsoft.EntityFrameworkCore;

namespace Ftcms;

public partial class ParticipantsWindow : Window
{
    private readonly int _courseId;

    public ParticipantsWindow(int courseId)
    {
        InitializeComponent();
        _courseId = courseId;
        using (var db = new AppDb())
            Header.Text = db.Courses.Find(courseId)?.Title ?? "";
        Load();
    }

    private void Load()
    {
        using var db = new AppDb();
        var list = db.Enrollments.Include(e => e.Instructor).Include(e => e.Certificate)
            .Where(e => e.CourseId == _courseId).ToList()
            .OrderBy(e => e.Instructor.LastName).ThenBy(e => e.Instructor.FirstName).ToList();
        Grid.ItemsSource = list;
        Summary.Text = $"{Jalali.ToFa(list.Count.ToString())} شرکت‌کننده، " +
                       $"{Jalali.ToFa(list.Count(e => e.Status == St.Completed).ToString())} نفر تکمیل‌کننده، " +
                       $"{Jalali.ToFa(list.Count(e => e.Certificate != null).ToString())} گواهی صادرشده";
    }

    private List<int> SelectedIds() => Grid.SelectedItems.Cast<Enrollment>().Select(e => e.Id).ToList();

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        List<int> existing;
        using (var db = new AppDb())
            existing = db.Enrollments.Where(x => x.CourseId == _courseId).Select(x => x.InstructorId).ToList();

        var dlg = new PickInstructorsWindow(existing) { Owner = this };
        if (dlg.ShowDialog() != true) return;

        using (var db = new AppDb())
        {
            foreach (var id in dlg.SelectedIds)
                db.Enrollments.Add(new Enrollment { CourseId = _courseId, InstructorId = id });
            db.SaveChanges();
        }
        Audit.Log("افزودن شرکت‌کننده", $"{Header.Text}: {dlg.SelectedIds.Count} نفر");
        Load();
    }

    private void SetStatus(string status)
    {
        var ids = SelectedIds();
        if (ids.Count == 0) { Msg.Info("ابتدا یک یا چند ردیف را انتخاب کنید."); return; }
        using (var db = new AppDb())
        {
            foreach (var en in db.Enrollments.Where(x => ids.Contains(x.Id)).ToList())
                en.Status = status;
            db.SaveChanges();
        }
        Audit.Log("تغییر وضعیت شرکت‌کننده", $"{Header.Text}: {ids.Count} نفر");
        Load();
    }

    private void Complete_Click(object sender, RoutedEventArgs e) => SetStatus(St.Completed);
    private void Absent_Click(object sender, RoutedEventArgs e) => SetStatus(St.Absent);
    private void Registered_Click(object sender, RoutedEventArgs e) => SetStatus(St.Registered);

    private void Remove_Click(object sender, RoutedEventArgs e)
    {
        var ids = SelectedIds();
        if (ids.Count == 0) return;
        using var db = new AppDb();
        var items = db.Enrollments.Include(x => x.Certificate).Where(x => ids.Contains(x.Id)).ToList();
        if (items.Any(x => x.Certificate != null))
        { Msg.Error("برای شرکت‌کننده‌ای که گواهی دارد حذف ممکن نیست؛ گواهی را باطل کنید."); return; }
        if (!Msg.Confirm($"{Jalali.ToFa(items.Count.ToString())} نفر از این دوره حذف شوند؟")) return;
        db.Enrollments.RemoveRange(items);
        db.SaveChanges();
        Audit.Log("حذف شرکت‌کننده", $"{Header.Text}: {items.Count} نفر");
        Load();
    }

    private void Issue_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            int created = MainWindow.IssueForCourse(_courseId);
            Msg.Info($"{Jalali.ToFa(created.ToString())} گواهی جدید صادر شد.");
            Load();
        }
        catch (Exception ex) { Msg.Error("صدور گواهی ناموفق بود:\n" + ex.Message); }
    }

    private void Grid_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (Grid.SelectedItem is not Enrollment en || en.Certificate == null) return;
        try { CertificateService.OpenPdf(en.Certificate); }
        catch (Exception ex) { Msg.Error("نمایش PDF ناموفق بود:\n" + ex.Message); }
    }
}
