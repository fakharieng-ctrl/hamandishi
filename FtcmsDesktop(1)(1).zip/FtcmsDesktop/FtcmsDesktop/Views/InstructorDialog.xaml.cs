using System.Windows;
using System.Windows.Controls;
using Ftcms.Data;
using Ftcms.Services;
using Microsoft.EntityFrameworkCore;

namespace Ftcms;

public partial class InstructorDialog : Window
{
    private readonly int _id;   // 0 = استاد جدید

    public InstructorDialog(Instructor existing = null)
    {
        InitializeComponent();

        using (var db = new AppDb())
        {
            College.ItemsSource = db.Instructors.Select(i => i.College).Where(x => x != "").Distinct().ToList();
            Department.ItemsSource = db.Instructors.Select(i => i.Department).Where(x => x != "").Distinct().ToList();
        }

        Gender.SelectedIndex = 0;
        if (existing == null) return;

        _id = existing.Id;
        Title = "ویرایش استاد";
        NationalCode.Text = existing.NationalCode;
        FirstName.Text = existing.FirstName;
        LastName.Text = existing.LastName;
        Gender.SelectedIndex = existing.IsMale ? 0 : 1;
        HasDoctorate.IsChecked = existing.HasDoctorate;
        Rank.Text = existing.Rank;
        College.Text = existing.College;
        Department.Text = existing.Department;
        PersonnelCode.Text = existing.PersonnelCode;
        Email.Text = existing.Email;
        Phone.Text = existing.Phone;
    }

    private static string RankText(ComboBox c) =>
        c.SelectedItem is ComboBoxItem it ? it.Content.ToString() : c.Text;

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        var code = Jalali.ToEn(NationalCode.Text.Trim());
        if (code.Length != 10 || !code.All(char.IsDigit)) { Msg.Error("کد ملی باید دقیقاً ۱۰ رقم باشد."); return; }
        if (string.IsNullOrWhiteSpace(FirstName.Text) || string.IsNullOrWhiteSpace(LastName.Text))
        { Msg.Error("نام و نام خانوادگی را وارد کنید."); return; }

        try
        {
            using var db = new AppDb();
            if (db.Instructors.Any(i => i.NationalCode == code && i.Id != _id))
            { Msg.Error("استادی با این کد ملی قبلاً ثبت شده است."); return; }

            var ins = _id == 0 ? new Instructor() : db.Instructors.Find(_id);
            ins.NationalCode = code;
            ins.FirstName = Jalali.Norm(FirstName.Text);
            ins.LastName = Jalali.Norm(LastName.Text);
            ins.IsMale = Gender.SelectedIndex != 1;
            ins.HasDoctorate = HasDoctorate.IsChecked == true;
            ins.Rank = Jalali.Norm(RankText(Rank));
            ins.College = Jalali.Norm(College.Text);
            ins.Department = Jalali.Norm(Department.Text);
            ins.PersonnelCode = Jalali.ToEn(PersonnelCode.Text.Trim());
            ins.Email = Email.Text.Trim();
            ins.Phone = Jalali.ToEn(Phone.Text.Trim());
            if (_id == 0) db.Instructors.Add(ins);
            db.SaveChanges();

            Audit.Log(_id == 0 ? "افزودن استاد" : "ویرایش استاد", ins.FullName);
            DialogResult = true;
        }
        catch (DbUpdateException ex) { Msg.Error("ذخیره انجام نشد:\n" + ex.InnerException?.Message); }
    }
}
