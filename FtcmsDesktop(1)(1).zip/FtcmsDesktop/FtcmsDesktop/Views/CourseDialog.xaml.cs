using System.Globalization;
using System.Windows;
using Ftcms.Data;
using Ftcms.Services;

namespace Ftcms;

public partial class CourseDialog : Window
{
    private readonly int _id;   // 0 = دوره جدید

    public CourseDialog(Course existing = null)
    {
        InitializeComponent();
        StatusBox.ItemsSource = St.CourseStatuses.Select(s => new { s.Key, s.Text }).ToList();
        StatusBox.SelectedValue = St.Planned;
        Start.Text = Jalali.ToFa(Jalali.Numeric(DateTime.Today));

        if (existing == null) return;
        _id = existing.Id;
        Title = "ویرایش دوره";
        CourseTitle.Text = existing.Title;
        Code.Text = existing.Code;
        Hours.Text = existing.Hours.ToString("0.#", CultureInfo.InvariantCulture);
        Start.Text = Jalali.ToFa(Jalali.Numeric(existing.StartDate));
        End.Text = existing.EndDate.HasValue ? Jalali.ToFa(Jalali.Numeric(existing.EndDate.Value)) : "";
        Presenter.Text = existing.Presenter;
        Location.Text = existing.Location;
        StatusBox.SelectedValue = existing.Status;
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(CourseTitle.Text)) { Msg.Error("عنوان دوره را وارد کنید."); return; }
        if (!double.TryParse(Jalali.ToEn(Hours.Text.Trim()).Replace('،', '.').Replace('٫', '.'),
                NumberStyles.Float, CultureInfo.InvariantCulture, out var hours) || hours <= 0)
        { Msg.Error("مدت دوره را به‌صورت عدد (ساعت) وارد کنید."); return; }
        if (!Jalali.TryParse(Start.Text, out var start)) { Msg.Error("تاریخ شروع معتبر نیست. نمونه: ۱۴۰۵/۰۸/۱۸"); return; }

        DateTime? end = null;
        if (!string.IsNullOrWhiteSpace(End.Text))
        {
            if (!Jalali.TryParse(End.Text, out var ed)) { Msg.Error("تاریخ پایان معتبر نیست."); return; }
            if (ed < start) { Msg.Error("تاریخ پایان نباید قبل از شروع باشد."); return; }
            end = ed;
        }

        using var db = new AppDb();
        var c = _id == 0 ? new Course() : db.Courses.Find(_id);
        c.Title = Jalali.Norm(CourseTitle.Text);
        c.Code = Code.Text.Trim();
        c.Hours = hours;
        c.StartDate = start;
        c.EndDate = end;
        c.Presenter = Jalali.Norm(Presenter.Text);
        c.Location = Jalali.Norm(Location.Text);
        c.Status = StatusBox.SelectedValue as string ?? St.Planned;
        if (_id == 0) db.Courses.Add(c);
        db.SaveChanges();

        Audit.Log(_id == 0 ? "ایجاد دوره" : "ویرایش دوره", c.Title);
        DialogResult = true;
    }
}
