using System.Windows;
using System.Windows.Controls;
using Ftcms.Data;
using Ftcms.Services;

namespace Ftcms;

public partial class PickInstructorsWindow : Window
{
    private readonly HashSet<int> _exclude;
    public List<int> SelectedIds { get; private set; } = new();

    public PickInstructorsWindow(IEnumerable<int> excludeIds)
    {
        InitializeComponent();
        _exclude = excludeIds.ToHashSet();
        Load();
    }

    private void Load()
    {
        using var db = new AppDb();
        var q = db.Instructors.Where(i => i.IsActive);
        var t = Jalali.Norm(Search?.Text ?? "");
        if (t.Length > 0)
        {
            var en = Jalali.ToEn(t);
            q = q.Where(i => i.FirstName.Contains(t) || i.LastName.Contains(t) || i.NationalCode.Contains(en));
        }
        Grid.ItemsSource = q.OrderBy(i => i.LastName).ThenBy(i => i.FirstName).ToList()
            .Where(i => !_exclude.Contains(i.Id)).ToList();
    }

    private void Search_Changed(object sender, TextChangedEventArgs e)
    {
        if (IsLoaded) Load();
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        SelectedIds = Grid.SelectedItems.Cast<Instructor>().Select(i => i.Id).ToList();
        if (SelectedIds.Count == 0) { Msg.Info("حداقل یک استاد را انتخاب کنید."); return; }
        DialogResult = true;
    }
}
