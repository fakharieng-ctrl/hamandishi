using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using Ftcms.Data;
using Microsoft.EntityFrameworkCore;

namespace Ftcms.Services;

public static class CertificateService
{
    // بدون حروف/ارقام مشابه (O/0 و I/1)
    private const string Alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    public static string VerifyUrl(Certificate c) =>
        SettingsStore.Current.BaseUrl.TrimEnd('/') + "/verify/" + c.VerifyCode;

    private static string NewCode()
    {
        var chars = new char[12];
        for (int i = 0; i < chars.Length; i++) chars[i] = Alphabet[RandomNumberGenerator.GetInt32(Alphabet.Length)];
        return new string(chars);
    }

    private static string NextSerial(AppDb db)
    {
        var prefix = $"{SettingsStore.Current.SerialPrefix}-{Jalali.Year(DateTime.Now)}-";
        var last = db.Certificates.Where(c => c.Serial.StartsWith(prefix))
            .OrderByDescending(c => c.Serial).Select(c => c.Serial).FirstOrDefault();
        var seq = last != null && int.TryParse(last[prefix.Length..], out var n) ? n + 1 : 1;
        return $"{prefix}{seq:00000}";
    }

    /// <summary>گواهی را صادر می‌کند. اگر قبلاً صادر شده باشد همان را برمی‌گرداند.</summary>
    public static (Certificate Cert, bool Created) Issue(AppDb db, Enrollment e)
    {
        var existing = db.Certificates.FirstOrDefault(c => c.EnrollmentId == e.Id);
        if (existing != null) return (existing, false);

        var ins = e.Instructor ?? db.Instructors.Find(e.InstructorId);
        var course = e.Course ?? db.Courses.Find(e.CourseId);
        var cert = new Certificate
        {
            EnrollmentId = e.Id,
            IssuedBy = Environment.UserName,
            HolderName = ins.CertificateName,
            HolderUnit = ins.UnitText,
            CourseTitle = course.Title,
            CourseHours = course.HoursText,
            CourseDates = course.DatesText,
        };

        for (int attempt = 0; attempt < 5; attempt++)
        {
            cert.Serial = NextSerial(db);
            cert.VerifyCode = NewCode();
            try
            {
                db.Certificates.Add(cert);
                db.SaveChanges();
                return (cert, true);
            }
            catch (DbUpdateException)
            {
                db.Entry(cert).State = EntityState.Detached;   // برخورد روی سریال/کد؛ دوباره تلاش می‌شود
            }
        }
        throw new InvalidOperationException("صدور گواهی پس از چند تلاش ناموفق بود.");
    }

    // ------------------------------------------------------------ PDF
    public static string SaveTempPdf(Certificate c)
    {
        Directory.CreateDirectory(Paths.TempDir);
        var path = Path.Combine(Paths.TempDir, c.Serial + ".pdf");
        File.WriteAllBytes(path, PdfService.Render(c));
        return path;
    }

    public static void OpenPdf(Certificate c)
    {
        var path = SaveTempPdf(c);
        Process.Start(new ProcessStartInfo { FileName = path, UseShellExecute = true });
    }
}
