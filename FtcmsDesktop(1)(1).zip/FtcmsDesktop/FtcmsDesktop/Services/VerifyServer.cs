using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Ftcms.Data;

namespace Ftcms.Services;

/// <summary>
/// وب‌سرور کوچک داخل برنامه برای صفحه استعلام عمومی گواهی (مقصد QR Code).
/// تا زمانی که برنامه روی آن رایانه باز است، صفحه /verify/کد در دسترس است.
/// </summary>
public static class VerifyServer
{
    private static HttpListener _listener;
    public static string Status { get; private set; } = "غیرفعال";

    public static void Start(int port)
    {
        Stop();
        var l = new HttpListener();
        try
        {
            l.Prefixes.Add($"http://+:{port}/");        // دسترسی از شبکه (نیازمند مجوز urlacl که نصب‌کننده تنظیم می‌کند)
            l.Start();
            Status = $"فعال روی شبکه (پورت {port})";
        }
        catch (HttpListenerException)
        {
            l.Close();
            l = new HttpListener();
            l.Prefixes.Add($"http://localhost:{port}/");  // فقط همین رایانه
            l.Start();
            Status = $"فعال فقط روی همین رایانه (پورت {port})";
        }
        _listener = l;
        _ = Task.Run(() => Loop(l));
    }

    public static void Stop()
    {
        try { _listener?.Close(); } catch { }
        _listener = null;
        Status = "غیرفعال";
    }

    private static async Task Loop(HttpListener l)
    {
        while (l.IsListening)
        {
            HttpListenerContext ctx;
            try { ctx = await l.GetContextAsync(); }
            catch { break; }
            _ = Task.Run(() => Handle(ctx));
        }
    }

    private static void Handle(HttpListenerContext ctx)
    {
        try
        {
            var path = ctx.Request.Url.AbsolutePath.TrimEnd('/');
            string html;
            int status = 200;

            if (ctx.Request.HttpMethod != "GET") { status = 405; html = Page("خطا", "<p>روش درخواست مجاز نیست.</p>"); }
            else if (path == "" || path == "/verify")
            {
                var q = ctx.Request.QueryString["code"];
                html = string.IsNullOrWhiteSpace(q) ? HomePage() : Result(Clean(q), out status);
            }
            else if (path.StartsWith("/verify/")) html = Result(Clean(path["/verify/".Length..]), out status);
            else { status = 404; html = Page("پیدا نشد", "<p>صفحه‌ای با این آدرس وجود ندارد.</p>"); }

            var bytes = Encoding.UTF8.GetBytes(html);
            ctx.Response.StatusCode = status;
            ctx.Response.ContentType = "text/html; charset=utf-8";
            ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
            ctx.Response.Headers["Cache-Control"] = "no-store";
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
        }
        catch { }
        finally { try { ctx.Response.Close(); } catch { } }
    }

    private static string Clean(string raw) =>
        Regex.Replace(Jalali.ToEn(raw ?? "").ToUpperInvariant(), "[^A-Z0-9]", "");

    private static string E(string s) => WebUtility.HtmlEncode(s ?? "");

    private static string HomePage() => Page("استعلام گواهی‌نامه", $@"
<h1>استعلام اعتبار گواهی‌نامه</h1>
<p>کد رهگیری ۱۲ حرفی چاپ‌شده روی گواهی را وارد کنید، یا QR Code گواهی را اسکن نمایید.</p>
<form method='get' action='/verify'><input name='code' placeholder='XXXX-XXXX-XXXX' dir='ltr' required autocomplete='off'>
<button>استعلام</button></form>");

    private static string Result(string code, out int status)
    {
        Certificate c = null;
        if (code.Length == 12)
        {
            using var db = new AppDb();
            c = db.Certificates.FirstOrDefault(x => x.VerifyCode == code);
        }
        if (c == null)
        {
            status = 404;
            return Page("نتیجه استعلام", @"<div class='box bad'><h2>گواهی‌ای با این کد پیدا نشد</h2>
<p>کد را دوباره بررسی کنید. اگر کد درست است، با دفتر هم‌اندیشی اساتید تماس بگیرید.</p></div><p><a href='/verify'>استعلام جدید</a></p>");
        }
        status = 200;
        if (!c.IsValid)
            return Page("نتیجه استعلام", $@"<div class='box bad'><h2>✖ این گواهی‌نامه باطل شده است</h2>
<dl><dt>شماره سریال</dt><dd dir='ltr'>{E(c.Serial)}</dd><dt>تاریخ ابطال</dt><dd>{E(Jalali.ToFa(c.RevokedAt.HasValue ? Jalali.Numeric(c.RevokedAt.Value) : "—"))}</dd></dl></div>
<p><a href='/verify'>استعلام جدید</a></p>");

        return Page("نتیجه استعلام", $@"<div class='box ok'><h2>✔ این گواهی‌نامه معتبر است</h2><dl>
<dt>دارنده</dt><dd>{E(c.HolderName)}</dd>
{(string.IsNullOrWhiteSpace(c.HolderUnit) ? "" : $"<dt>واحد</dt><dd>{E(c.HolderUnit)}</dd>")}
<dt>دوره</dt><dd>{E(c.CourseTitle)}</dd>
<dt>مدت</dt><dd>{E(Jalali.ToFa(c.CourseHours))} ساعت</dd>
<dt>تاریخ برگزاری</dt><dd>{E(Jalali.ToFa(c.CourseDates))}</dd>
<dt>تاریخ صدور</dt><dd>{E(Jalali.ToFa(c.IssueDateText))}</dd>
<dt>شماره سریال</dt><dd dir='ltr'>{E(c.Serial)}</dd>
<dt>کد رهگیری</dt><dd dir='ltr'>{E(c.DisplayCode)}</dd></dl></div>
<p><a href='/verify'>استعلام جدید</a></p>");
    }

    private static string _logo;

    private static string Page(string title, string body)
    {
        var s = SettingsStore.Current;
        _logo ??= Convert.ToBase64String(Assets.Bytes("logo_original.png"));
        return $@"<!doctype html><html lang='fa' dir='rtl'><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'><title>{E(title)}</title>
<style>body{{font-family:Tahoma,Vazirmatn,sans-serif;background:#f5f3ee;color:#1c1c1c;margin:0;line-height:1.9}}
.w{{max-width:620px;margin:30px auto;padding:0 16px;text-align:center}}img{{height:84px}}
h1{{color:#1b3a57;font-size:1.3rem}}.box{{background:#fff;border:2px solid;border-radius:10px;padding:14px 18px;margin:14px 0}}
.ok{{border-color:#1d7a46}}.ok h2{{color:#1d7a46}}.bad{{border-color:#b3261e}}.bad h2{{color:#b3261e}}
dl{{display:grid;grid-template-columns:max-content 1fr;gap:4px 18px;text-align:start}}dt{{color:#5b6770}}dd{{margin:0;font-weight:700}}
input{{padding:8px 12px;font:inherit;border:1px solid #c9c3b4;border-radius:8px;text-align:center}}
button{{padding:8px 18px;font:inherit;background:#1b3a57;color:#fff;border:0;border-radius:8px;cursor:pointer}}
small{{color:#5b6770}}</style></head><body><div class='w'>
<img src='data:image/png;base64,{_logo}' alt=''><p><small>{E(s.OfficeName)} — {E(s.OrgName)}</small></p>{body}</div></body></html>";
    }
}
