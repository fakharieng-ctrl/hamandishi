using System.Windows;
using Ftcms.Data;
using QRCoder;
using QuestPDF.Drawing;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace Ftcms.Services;

public static class Fonts
{
    public static string Family { get; private set; } = "Tahoma";

    /// <summary>اگر فایل‌های Vazirmatn در پوشه Assets\Fonts گذاشته و برنامه دوباره ساخته شود، استفاده می‌شوند.</summary>
    public static void Init()
    {
        foreach (var name in new[] { "Vazirmatn-Regular.ttf", "Vazirmatn-Bold.ttf" })
        {
            try
            {
                var info = Application.GetResourceStream(new Uri($"pack://application:,,,/Assets/Fonts/{name}"));
                if (info == null) continue;
                using var s = info.Stream;
                FontManager.RegisterFont(s);
                Family = "Vazirmatn";
            }
            catch { /* فونت اختیاری است */ }
        }
    }
}

public static class PdfService
{
    private const string Navy = "#1B3A57", Gold = "#A8822E", Gray = "#5B6770";

    private static byte[] MakeQr(string url)
    {
        using var gen = new QRCodeGenerator();
        using var data = gen.CreateQrCode(url, QRCodeGenerator.ECCLevel.Q);
        return new PngByteQRCode(data).GetGraphic(12);
    }

    public static byte[] Render(Certificate c)
    {
        var s = SettingsStore.Current;
        var logo = Assets.Bytes("logo.png");
        var watermark = Assets.Bytes("logo_watermark.png");
        var url = CertificateService.VerifyUrl(c);
        var qr = MakeQr(url);
        var font = Fonts.Family;
        var holderUnit = string.IsNullOrWhiteSpace(c.HolderUnit) ? null : "عضو هیئت علمی " + c.HolderUnit;
        var body = $"در دوره آموزشی «{c.CourseTitle}» به مدت {Jalali.ToFa(c.CourseHours)} ساعت " +
                   $"که در تاریخ {Jalali.ToFa(c.CourseDates)} برگزار گردید، شرکت نموده است.";

        var document = Document.Create(doc =>
        {
            doc.Page(p =>
            {
                p.Size(PageSizes.A4.Landscape());
                p.Margin(22);
                p.PageColor("#FFFDF8");
                p.ContentFromRightToLeft();
                p.DefaultTextStyle(t => t.FontFamily(font).FontSize(14).FontColor("#1C1C1C"));

                p.Content().Layers(layers =>
                {
                    // نشان محو پس‌زمینه
                    layers.Layer().AlignCenter().AlignMiddle().Width(300).Height(300).Image(watermark).FitArea();

                    // قاب و متن اصلی
                    layers.PrimaryLayer().Extend()
                        .Border(3).BorderColor(Navy).Padding(4)
                        .Border(0.8f).BorderColor(Gold).Padding(18)
                        .Column(col =>
                        {
                            col.Spacing(5);

                            col.Item().Row(r =>
                            {
                                r.RelativeItem().Column(info =>
                                {
                                    info.Item().Text($"شماره سریال: {c.Serial}").FontSize(10);
                                    info.Item().Text($"تاریخ صدور: {Jalali.ToFa(c.IssueDateText)}").FontSize(10);
                                });
                                r.RelativeItem();
                            });

                            col.Item().AlignCenter().Width(58).Height(58).Image(logo).FitArea();
                            col.Item().AlignCenter().Text(s.OrgName).FontSize(17).Bold().FontColor(Navy);
                            col.Item().AlignCenter().Text(s.OfficeName).FontSize(13).FontColor(Gray);

                            col.Item().PaddingTop(10).AlignCenter().Text("گواهی‌نامه").FontSize(34).Bold().FontColor(Gold);
                            col.Item().AlignCenter().Text("گواهی شرکت در دوره آموزشی").FontSize(13).FontColor(Gray);
                            col.Item().AlignCenter().Width(220).LineHorizontal(0.8f).LineColor(Gold);

                            col.Item().PaddingTop(10).AlignCenter().Text("بدین‌وسیله گواهی می‌شود که").FontSize(14);
                            col.Item().AlignCenter().Text(c.HolderName).FontSize(24).Bold().FontColor(Navy);
                            if (holderUnit != null)
                                col.Item().AlignCenter().Text(holderUnit).FontSize(12.5f).FontColor(Gray);

                            col.Item().PaddingTop(8).PaddingHorizontal(40).AlignCenter()
                                .Text(body).FontSize(14).LineHeight(1.7f).AlignCenter();
                        });

                    // پایین گواهی: امضاها (راست) و QR (چپ)
                    layers.Layer().AlignBottom().PaddingHorizontal(34).PaddingBottom(28).Row(r =>
                    {
                        r.RelativeItem().Element(e => Signer(e, s.Signer1Title, s.Signer1Name));
                        r.ConstantItem(16);
                        r.RelativeItem().Element(e => Signer(e, s.Signer2Title, s.Signer2Name));
                        r.ConstantItem(24);

                        r.RelativeItem(1.6f).AlignBottom().Column(info =>
                        {
                            info.Item().Text("استعلام اعتبار گواهی").FontSize(10.5f).Bold();
                            info.Item().Text("کد QR را اسکن کنید یا به آدرس زیر مراجعه نمایید:").FontSize(8.5f);
                            info.Item().Text(url.Replace("https://", "").Replace("http://", ""))
                                .FontSize(8).FontColor(Navy);
                            info.Item().Text($"کد رهگیری: {c.DisplayCode}").FontSize(9);
                            info.Item().Text($"سریال: {c.Serial}").FontSize(9);
                        });
                        r.ConstantItem(8);
                        r.ConstantItem(84).Border(0.8f).BorderColor(Gold).Background("#FFFFFF").Padding(3)
                            .Image(qr).FitArea();
                    });

                    // مهر باطل‌شده
                    if (!c.IsValid)
                        layers.Layer().AlignCenter().AlignMiddle().Rotate(-25)
                            .Text("باطل شده").FontSize(90).Bold().FontColor("#E9B7B2");
                });
            });
        })
        .WithMetadata(new DocumentMetadata { Title = $"گواهی {c.Serial}", Author = s.OfficeName })
        .WithSettings(new DocumentSettings { ImageCompressionQuality = ImageCompressionQuality.Best });

        return document.GeneratePdf();
    }

    private static void Signer(IContainer box, string title, string name)
    {
        box.Column(col =>
        {
            col.Item().Height(34).AlignCenter().AlignBottom()
                .Text(name ?? "").FontSize(11).Bold();
            col.Item().PaddingHorizontal(10).LineHorizontal(0.6f).LineColor(Gray);
            col.Item().PaddingTop(3).AlignCenter().Text(title).FontSize(11).FontColor(Gray);
        });
    }
}
