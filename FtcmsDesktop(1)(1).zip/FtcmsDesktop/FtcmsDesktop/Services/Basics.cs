using System.Globalization;
using System.IO;
using System.Text.Json;
using System.Windows;
using Ftcms.Data;

namespace Ftcms.Services;

// ---------------------------------------------------------------- تاریخ شمسی و ارقام
public static class Jalali
{
    private static readonly PersianCalendar Pc = new();

    public static readonly string[] Months =
        { "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند" };

    public static int Year(DateTime d) => Pc.GetYear(d);

    public static string Numeric(DateTime d) =>
        $"{Pc.GetYear(d):0000}/{Pc.GetMonth(d):00}/{Pc.GetDayOfMonth(d):00}";

    public static string Long(DateTime d) =>
        $"{Pc.GetDayOfMonth(d)} {Months[Pc.GetMonth(d) - 1]} {Pc.GetYear(d)}";

    public static string ToFa(string s)
    {
        if (string.IsNullOrEmpty(s)) return s ?? "";
        var chars = s.ToCharArray();
        for (int i = 0; i < chars.Length; i++)
            if (chars[i] >= '0' && chars[i] <= '9') chars[i] = (char)('۰' + (chars[i] - '0'));
        return new string(chars);
    }

    public static string ToEn(string s)
    {
        if (string.IsNullOrEmpty(s)) return s ?? "";
        var chars = s.ToCharArray();
        for (int i = 0; i < chars.Length; i++)
        {
            if (chars[i] >= '۰' && chars[i] <= '۹') chars[i] = (char)('0' + (chars[i] - '۰'));
            else if (chars[i] >= '٠' && chars[i] <= '٩') chars[i] = (char)('0' + (chars[i] - '٠'));
        }
        return new string(chars);
    }

    /// <summary>یکسان‌سازی «ي» و «ك» عربی با «ی» و «ک» فارسی.</summary>
    public static string Norm(string s) =>
        (s ?? "").Replace('ي', 'ی').Replace('ى', 'ی').Replace('ك', 'ک').Trim();

    /// <summary>تاریخ شمسی مانند 1405/08/18 را به میلادی تبدیل می‌کند.</summary>
    public static bool TryParse(string text, out DateTime date)
    {
        date = default;
        var p = ToEn((text ?? "").Trim()).Split('/', '-', '.');
        if (p.Length != 3) return false;
        if (!int.TryParse(p[0], out var y) || !int.TryParse(p[1], out var m) || !int.TryParse(p[2], out var d))
            return false;
        try { date = Pc.ToDateTime(y, m, d, 0, 0, 0, 0); return true; }
        catch { return false; }
    }
}

// ---------------------------------------------------------------- تنظیمات
public class AppSettings
{
    public string OrgName { get; set; } = "دانشگاه علوم پزشکی بوشهر";
    public string OfficeName { get; set; } = "دفتر هم‌اندیشی اساتید";
    public string SerialPrefix { get; set; } = "BUMS";
    public string BaseUrl { get; set; } = "http://localhost:8080";
    public int Port { get; set; } = 8080;
    public bool EnableServer { get; set; } = true;
    public string Signer1Title { get; set; } = "رئیس دانشگاه";
    public string Signer1Name { get; set; } = "";
    public string Signer2Title { get; set; } = "معاون آموزشی دانشگاه";
    public string Signer2Name { get; set; } = "";
}

public static class SettingsStore
{
    public static AppSettings Current { get; private set; } = new();

    public static void Load()
    {
        try
        {
            if (File.Exists(Paths.SettingsFile))
                Current = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(Paths.SettingsFile)) ?? new();
        }
        catch { Current = new(); }
    }

    public static void Save(AppSettings s)
    {
        Directory.CreateDirectory(Paths.Dir);
        File.WriteAllText(Paths.SettingsFile,
            JsonSerializer.Serialize(s, new JsonSerializerOptions { WriteIndented = true,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping }));
        Current = s;
    }
}

// ---------------------------------------------------------------- گزارش رویدادها
public static class Audit
{
    public static void Log(string action, string detail = "")
    {
        try
        {
            using var db = new AppDb();
            db.AuditLogs.Add(new AuditLog { User = Environment.UserName, Action = action, Detail = detail });
            db.SaveChanges();
        }
        catch { /* ثبت رویداد نباید کار اصلی را متوقف کند */ }
    }
}

// ---------------------------------------------------------------- فایل‌های داخل برنامه
public static class Assets
{
    public static byte[] Bytes(string name)
    {
        var info = Application.GetResourceStream(new Uri($"pack://application:,,,/Assets/{name}"));
        using var s = info.Stream;
        using var ms = new MemoryStream();
        s.CopyTo(ms);
        return ms.ToArray();
    }
}

// ---------------------------------------------------------------- پیام‌ها (راست‌به‌چپ)
public static class Msg
{
    private const MessageBoxOptions Rtl = MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign;

    public static void Info(string text) =>
        MessageBox.Show(text, "سامانه آموزش اساتید", MessageBoxButton.OK, MessageBoxImage.Information,
            MessageBoxResult.OK, Rtl);

    public static void Error(string text) =>
        MessageBox.Show(text, "خطا", MessageBoxButton.OK, MessageBoxImage.Error, MessageBoxResult.OK, Rtl);

    public static bool Confirm(string text) =>
        MessageBox.Show(text, "تأیید", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No, Rtl)
        == MessageBoxResult.Yes;
}
