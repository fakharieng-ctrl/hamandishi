using ClosedXML.Excel;
using Ftcms.Data;

namespace Ftcms.Services;

public static class ExcelService
{
    private static readonly string[] Headers =
    {
        "کد ملی", "نام", "نام خانوادگی", "جنسیت (آقا/خانم)", "دکتری (بله/خیر)", "مرتبه علمی",
        "دانشکده", "گروه آموزشی", "کد پرسنلی", "ایمیل", "تلفن"
    };

    /// <summary>جلوگیری از اجرای فرمول در Excel (Formula Injection).</summary>
    private static string Safe(string v) =>
        !string.IsNullOrEmpty(v) && "=+-@".IndexOf(v[0]) >= 0 ? "'" + v : v ?? "";

    private static IXLWorksheet NewSheet(XLWorkbook wb)
    {
        var ws = wb.AddWorksheet("اساتید");
        ws.RightToLeft = true;
        for (int i = 0; i < Headers.Length; i++)
        {
            var cell = ws.Cell(1, i + 1);
            cell.Value = Headers[i];
            cell.Style.Font.Bold = true;
            cell.Style.Font.FontColor = XLColor.White;
            cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#1B3A57");
            ws.Column(i + 1).Width = 20;
        }
        foreach (var col in new[] { 1, 9, 11 }) ws.Column(col).Style.NumberFormat.Format = "@";
        ws.SheetView.FreezeRows(1);
        return ws;
    }

    public static void ExportInstructors(IEnumerable<Instructor> items, string path)
    {
        using var wb = new XLWorkbook();
        var ws = NewSheet(wb);
        int r = 2;
        foreach (var i in items)
        {
            ws.Cell(r, 1).Value = Safe(i.NationalCode);
            ws.Cell(r, 2).Value = Safe(i.FirstName);
            ws.Cell(r, 3).Value = Safe(i.LastName);
            ws.Cell(r, 4).Value = i.IsMale ? "آقا" : "خانم";
            ws.Cell(r, 5).Value = i.HasDoctorate ? "بله" : "خیر";
            ws.Cell(r, 6).Value = Safe(i.Rank);
            ws.Cell(r, 7).Value = Safe(i.College);
            ws.Cell(r, 8).Value = Safe(i.Department);
            ws.Cell(r, 9).Value = Safe(i.PersonnelCode);
            ws.Cell(r, 10).Value = Safe(i.Email);
            ws.Cell(r, 11).Value = Safe(i.Phone);
            r++;
        }
        wb.SaveAs(path);
    }

    public static void SaveTemplate(string path)
    {
        using var wb = new XLWorkbook();
        var ws = NewSheet(wb);
        ws.Cell(2, 1).Value = "0012345678";
        ws.Cell(2, 2).Value = "علی";
        ws.Cell(2, 3).Value = "رضایی";
        ws.Cell(2, 4).Value = "آقا";
        ws.Cell(2, 5).Value = "بله";
        ws.Cell(2, 6).Value = "استادیار";
        ws.Cell(2, 7).Value = "دانشکده پزشکی";
        ws.Cell(2, 8).Value = "داخلی";
        wb.SaveAs(path);
    }

    /// <summary>ورود گروهی. ردیف‌های تکراری (کد ملی موجود) به‌روزرسانی می‌شوند.</summary>
    public static (int Added, int Updated, List<string> Errors) ImportInstructors(string path)
    {
        var errors = new List<string>();
        int added = 0, updated = 0;

        using var wb = new XLWorkbook(path);
        var ws = wb.Worksheets.First();
        var last = ws.LastRowUsed()?.RowNumber() ?? 1;

        using var db = new AppDb();
        for (int r = 2; r <= last; r++)
        {
            string Get(int c) => Jalali.Norm(ws.Cell(r, c).GetString());
            var code = Jalali.ToEn(Get(1));
            var first = Get(2);
            var lastName = Get(3);
            if (code == "" && first == "" && lastName == "") continue;          // ردیف خالی

            if (code.Length == 9) code = "0" + code;                             // Excel صفر ابتدایی را حذف می‌کند
            if (code.Length != 10 || !code.All(char.IsDigit)) { errors.Add($"ردیف {r}: کد ملی باید ۱۰ رقم باشد."); continue; }
            if (first == "" || lastName == "") { errors.Add($"ردیف {r}: نام و نام خانوادگی لازم است."); continue; }

            var ins = db.Instructors.FirstOrDefault(i => i.NationalCode == code);
            var isNew = ins == null;
            ins ??= new Instructor { NationalCode = code };
            ins.FirstName = first;
            ins.LastName = lastName;
            ins.IsMale = Get(4) != "خانم";
            ins.HasDoctorate = Get(5) != "خیر";
            ins.Rank = Get(6);
            ins.College = Get(7);
            ins.Department = Get(8);
            ins.PersonnelCode = Jalali.ToEn(Get(9));
            ins.Email = Get(10);
            ins.Phone = Jalali.ToEn(Get(11));
            if (isNew) { db.Instructors.Add(ins); added++; } else updated++;
        }
        db.SaveChanges();
        return (added, updated, errors);
    }
}
