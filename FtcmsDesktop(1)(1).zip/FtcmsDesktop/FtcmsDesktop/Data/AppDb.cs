using Microsoft.EntityFrameworkCore;

namespace Ftcms.Data;

public static class Paths
{
    public static readonly string Dir =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FTCMS");
    public static string DbFile => Path.Combine(Dir, "ftcms.db");
    public static string SettingsFile => Path.Combine(Dir, "settings.json");
    public static string ErrorLog => Path.Combine(Dir, "error.log");
    public static string TempDir => Path.Combine(Path.GetTempPath(), "FTCMS");
}

public class AppDb : DbContext
{
    public DbSet<Instructor> Instructors => Set<Instructor>();
    public DbSet<Course> Courses => Set<Course>();
    public DbSet<Enrollment> Enrollments => Set<Enrollment>();
    public DbSet<Certificate> Certificates => Set<Certificate>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    protected override void OnConfiguring(DbContextOptionsBuilder o) =>
        o.UseSqlite($"Data Source={Paths.DbFile}");

    protected override void OnModelCreating(ModelBuilder m)
    {
        m.Entity<Instructor>().HasIndex(x => x.NationalCode).IsUnique();
        m.Entity<Enrollment>().HasIndex(x => new { x.CourseId, x.InstructorId }).IsUnique();
        m.Entity<Certificate>().HasIndex(x => x.Serial).IsUnique();
        m.Entity<Certificate>().HasIndex(x => x.VerifyCode).IsUnique();
        m.Entity<Certificate>().HasIndex(x => x.EnrollmentId).IsUnique();

        // سوابق نباید با حذف رکورد دیگر پاک شوند
        m.Entity<Enrollment>().HasOne(e => e.Course).WithMany(c => c.Enrollments)
            .HasForeignKey(e => e.CourseId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Enrollment>().HasOne(e => e.Instructor).WithMany(i => i.Enrollments)
            .HasForeignKey(e => e.InstructorId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Certificate>().HasOne(c => c.Enrollment).WithOne(e => e.Certificate)
            .HasForeignKey<Certificate>(c => c.EnrollmentId).OnDelete(DeleteBehavior.Restrict);
    }
}
