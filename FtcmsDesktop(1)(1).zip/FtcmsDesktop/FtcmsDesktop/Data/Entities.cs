using System.ComponentModel.DataAnnotations.Schema;
using Ftcms.Services;

namespace Ftcms.Data;

public static class St
{
    public const string Registered = "registered", Completed = "completed", Absent = "absent";
    public const string Valid = "valid", Revoked = "revoked";
    public const string Planned = "planned", Running = "running", Finished = "finished", Cancelled = "cancelled";

    public static readonly (string Key, string Text)[] CourseStatuses =
    {
        (Planned, "برنامه‌ریزی‌شده"), (Running, "در حال برگزاری"), (Finished, "پایان‌یافته"), (Cancelled, "لغوشده")
    };
}

public class Instructor
{
    public int Id { get; set; }
    public string NationalCode { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public bool IsMale { get; set; } = true;
    public bool HasDoctorate { get; set; } = true;
    public string Rank { get; set; } = "";
    public string College { get; set; } = "";
    public string Department { get; set; } = "";
    public string PersonnelCode { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public List<Enrollment> Enrollments { get; set; } = new();

    [NotMapped] public string FullName => $"{FirstName} {LastName}".Trim();
    [NotMapped] public string GenderText => IsMale ? "آقا" : "خانم";
    [NotMapped] public string StatusText => IsActive ? "فعال" : "غیرفعال";

    [NotMapped]
    public string CertificateName
    {
        get
        {
            var prefix = IsMale ? "جناب آقای" : "سرکار خانم";
            if (HasDoctorate) prefix += " دکتر";
            return $"{prefix} {FullName}";
        }
    }

    [NotMapped]
    public string UnitText
    {
        get
        {
            if (string.IsNullOrWhiteSpace(Department)) return "";
            return string.IsNullOrWhiteSpace(College)
                ? $"گروه آموزشی {Department}"
                : $"گروه آموزشی {Department}، {College}";
        }
    }
}

public class Course
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Code { get; set; } = "";
    public double Hours { get; set; }
    public DateTime StartDate { get; set; } = DateTime.Today;
    public DateTime? EndDate { get; set; }
    public string Presenter { get; set; } = "";
    public string Location { get; set; } = "";
    public string Status { get; set; } = St.Planned;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public List<Enrollment> Enrollments { get; set; } = new();

    [NotMapped] public string HoursText => Hours == Math.Floor(Hours) ? ((int)Hours).ToString() : Hours.ToString("0.#");
    [NotMapped] public string StartText => Jalali.Numeric(StartDate);
    [NotMapped] public string StatusText => St.CourseStatuses.FirstOrDefault(s => s.Key == Status).Text ?? Status;

    [NotMapped]
    public string DatesText
    {
        get
        {
            if (EndDate.HasValue && EndDate.Value.Date != StartDate.Date)
                return $"از {Jalali.Long(StartDate)} تا {Jalali.Long(EndDate.Value)}";
            return Jalali.Long(StartDate);
        }
    }
}

public class Enrollment
{
    public int Id { get; set; }
    public int CourseId { get; set; }
    public Course Course { get; set; }
    public int InstructorId { get; set; }
    public Instructor Instructor { get; set; }
    public string Status { get; set; } = St.Registered;
    public Certificate Certificate { get; set; }

    [NotMapped]
    public string StatusText => Status switch
    {
        St.Completed => "تکمیل دوره",
        St.Absent => "غایب / انصراف",
        _ => "ثبت‌نام‌شده"
    };
}

public class Certificate
{
    public int Id { get; set; }
    public int EnrollmentId { get; set; }
    public Enrollment Enrollment { get; set; }

    public string Serial { get; set; } = "";
    public string VerifyCode { get; set; } = "";
    public string Status { get; set; } = St.Valid;
    public DateTime IssuedAt { get; set; } = DateTime.Now;
    public string IssuedBy { get; set; } = "";
    public DateTime? RevokedAt { get; set; }
    public string RevokedReason { get; set; } = "";

    // نسخه ثابت اطلاعات هنگام صدور؛ با ویرایش بعدی استاد یا دوره تغییر نمی‌کند
    public string HolderName { get; set; } = "";
    public string HolderUnit { get; set; } = "";
    public string CourseTitle { get; set; } = "";
    public string CourseHours { get; set; } = "";
    public string CourseDates { get; set; } = "";

    [NotMapped] public bool IsValid => Status == St.Valid;
    [NotMapped] public string StatusText => IsValid ? "معتبر" : "باطل‌شده";
    [NotMapped] public string IssueDateText => Jalali.Numeric(IssuedAt);

    [NotMapped]
    public string DisplayCode =>
        VerifyCode.Length == 12 ? $"{VerifyCode[..4]}-{VerifyCode[4..8]}-{VerifyCode[8..]}" : VerifyCode;
}

public class AuditLog
{
    public int Id { get; set; }
    public DateTime At { get; set; } = DateTime.Now;
    public string User { get; set; } = "";
    public string Action { get; set; } = "";
    public string Detail { get; set; } = "";

    [NotMapped] public string AtText => $"{Jalali.Numeric(At)}  {At:HH:mm}";
}
