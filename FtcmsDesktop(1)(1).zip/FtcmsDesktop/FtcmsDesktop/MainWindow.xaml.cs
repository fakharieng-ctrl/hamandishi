using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Ftcms.Data;
using Ftcms.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;

namespace Ftcms;

public class CourseRow
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string Start { get; set; }
    public string Hours { get; set; }
    public string Total { get; set; }
    public string Done { get; set; }
    public string Certs { get; set; }
    public string Status { get; set; }
}

public class BarRow
{
    public string Name { get; set; }
    public double Percent { get; set; }
    public string CountText { get; set; }
}

public partial class MainWindow : Window
{
    private bool _ready;

    public MainWindow()
    {
        InitializeComponent();
        LoadSettingsUi();
        _ready = true;
        RefreshAll();
    }

    private static string Fa(int n) => Jalali.ToFa(n.ToString());

    private void RefreshAll()
    {
        var s = SettingsStore.Current;
        HeaderText.Text = $"{s.OfficeName} — {s.OrgName}";
        LoadDashboard();
        LoadInstructors();
        LoadCourses();
        LoadCerts();
        LoadLogs();
    }

    private void Tabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready || !ReferenceEquals(e.Source, Tabs)) return;   // رویدادهای DataGrid/ComboBox داخل تب‌ها را نادیده بگیر
        RefreshAll();
    }

    // ============================================================ داشبورد
    private void LoadDashboard()
    {
        using var db = new AppDb();
        StatInstructors.Text = Fa(db.Instructors.Count(i => i.IsActive));
        StatCourses.Text = Fa(db.Courses.Count());
        StatValid.Text = Fa(db.Certificates.Count(c => c.Status == St.Valid));
        StatRevoked.Text = Fa(db.Certificates.Count(c => c.Status == St.Revoked));

        var colleges = db.Certificates.Where(c => c.Status == St.Valid)
            .Select(c => c.Enrollment.Instructor.College).ToList()
            .GroupBy(x => string.IsNullOrWhiteSpace(x) ? "نامشخص" : x)
            .Select(g => new { Name = g.Key, N = g.Count() }).OrderByDescending(x => x.N).Take(8).ToList();
        var max = Math.Max(1, colleges.Select(x => x.N).DefaultIfEmpty(1).Max());
        CollegeBars.ItemsSource = colleges.Select(x => new BarRow
        { Name = x.Name, Percent = 100.0 * x.N / max, CountText = Fa(x.N) }).ToList();

        GridRecent.ItemsSource = db.Certificates.OrderByDescending(c => c.IssuedAt).Take(8).ToList();
    }

    private void Recent_DoubleClick(object sender, MouseButtonEventArgs e) => OpenPdf(GridRecent.SelectedItem as Certificate);

    // ============================================================ اساتید
    private void LoadInstructors()
    {
        using var db = new AppDb();
        var list = FilteredInstructors(db).OrderBy(i => i.LastName).ThenBy(i => i.FirstName).ToList();
        GridIns.ItemsSource = list;
        InsCount.Text = $"{Fa(list.Count)} مورد";
    }

    private IQueryable<Instructor> FilteredInstructors(AppDb db)
    {
        var q = db.Instructors.AsQueryable();
        var t = Jalali.Norm(SearchIns.Text);
        if (t.Length > 0)
        {
            var en = Jalali.ToEn(t);
            q = q.Where(i => i.FirstName.Contains(t) || i.LastName.Contains(t)
                             || i.NationalCode.Contains(en) || i.PersonnelCode.Contains(en));
        }
        return q;
    }

    private void SearchIns_Changed(object sender, TextChangedEventArgs e)
    {
        if (_ready) LoadInstructors();
    }

    private void AddInstructor_Click(object sender, RoutedEventArgs e)
    {
        if (new InstructorDialog { Owner = this }.ShowDialog() == true) { LoadInstructors(); LoadDashboard(); }
    }

    private void EditInstructor_Click(object sender, RoutedEventArgs e)
    {
        if (GridIns.SelectedItem is not Instructor ins) { Msg.Info("ابتدا یک استاد را انتخاب کنید."); return; }
        if (new InstructorDialog(ins) { Owner = this }.ShowDialog() == true) LoadInstructors();
    }

    private void ToggleInstructor_Click(object sender, RoutedEventArgs e)
    {
        var ids = GridIns.SelectedItems.Cast<Instructor>().Select(i => i.Id).ToList();
        if (ids.Count == 0) { Msg.Info("ابتدا یک یا چند استاد را انتخاب کنید."); return; }
        using (var db = new AppDb())
        {
            foreach (var i in db.Instructors.Where(x => ids.Contains(x.Id)).ToList()) i.IsActive = !i.IsActive;
            db.SaveChanges();
        }
        Audit.Log("تغییر وضعیت فعال/غیرفعال اساتید", $"{ids.Count} مورد");
        LoadInstructors();
        LoadDashboard();
    }

    private void ImportInstructors_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "Excel (*.xlsx)|*.xlsx", Title = "فایل Excel اساتید" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            var (added, updated, errors) = ExcelService.ImportInstructors(dlg.FileName);
            Audit.Log("ورود اساتید از Excel", $"{added} جدید، {updated} به‌روزرسانی، {errors.Count} خطا");
            var text = $"{Fa(added)} استاد جدید اضافه و {Fa(updated)} استاد به‌روزرسانی شد.";
            if (errors.Count > 0)
                text += $"\n\n{Fa(errors.Count)} ردیف رد شد:\n" + string.Join("\n", errors.Take(15)) +
                        (errors.Count > 15 ? "\n…" : "");
            Msg.Info(text);
            LoadInstructors();
            LoadDashboard();
        }
        catch (Exception ex) { Msg.Error("خواندن فایل ناموفق بود (فایل باید .xlsx و بسته باشد):\n" + ex.Message); }
    }

    private void ExportInstructors_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new SaveFileDialog { Filter = "Excel (*.xlsx)|*.xlsx", FileName = "instructors.xlsx" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            using var db = new AppDb();
            var list = FilteredInstructors(db).OrderBy(i => i.LastName).ThenBy(i => i.FirstName).ToList();
            ExcelService.ExportInstructors(list, dlg.FileName);
            Audit.Log("خروجی Excel اساتید", $"{list.Count} مورد");
            Msg.Info("فایل ذخیره شد.");
        }
        catch (Exception ex) { Msg.Error("ذخیره فایل ناموفق بود:\n" + ex.Message); }
    }

    private void TemplateInstructors_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new SaveFileDialog { Filter = "Excel (*.xlsx)|*.xlsx", FileName = "instructors-template.xlsx" };
        if (dlg.ShowDialog(this) != true) return;
        try { ExcelService.SaveTemplate(dlg.FileName); Msg.Info("فایل نمونه ذخیره شد. ردیف دوم نمونه است؛ آن را پاک کنید یا ویرایش کنید."); }
        catch (Exception ex) { Msg.Error(ex.Message); }
    }

    // ============================================================ دوره‌ها
    private void LoadCourses()
    {
        using var db = new AppDb();
        var courses = db.Courses.Include(c => c.Enrollments).ThenInclude(en => en.Certificate)
            .OrderByDescending(c => c.StartDate).ToList();
        GridCourses.ItemsSource = courses.Select(c => new CourseRow
        {
            Id = c.Id, Title = c.Title, Start = Jalali.ToFa(c.StartText), Hours = Jalali.ToFa(c.HoursText),
            Total = Fa(c.Enrollments.Count),
            Done = Fa(c.Enrollments.Count(x => x.Status == St.Completed)),
            Certs = Fa(c.Enrollments.Count(x => x.Certificate != null)),
            Status = c.StatusText,
        }).ToList();
    }

    private void AddCourse_Click(object sender, RoutedEventArgs e)
    {
        if (new CourseDialog { Owner = this }.ShowDialog() == true) { LoadCourses(); LoadDashboard(); }
    }

    private void EditCourse_Click(object sender, RoutedEventArgs e)
    {
        if (GridCourses.SelectedItem is not CourseRow row) { Msg.Info("ابتدا یک دوره را انتخاب کنید."); return; }
        using var db = new AppDb();
        var c = db.Courses.Find(row.Id);
        if (new CourseDialog(c) { Owner = this }.ShowDialog() == true) LoadCourses();
    }

    private void Participants_Click(object sender, RoutedEventArgs e)
    {
        if (GridCourses.SelectedItem is not CourseRow row) { Msg.Info("ابتدا یک دوره را انتخاب کنید."); return; }
        new ParticipantsWindow(row.Id) { Owner = this }.ShowDialog();
        LoadCourses();
        LoadCerts();
        LoadDashboard();
    }

    private void IssueCourse_Click(object sender, RoutedEventArgs e)
    {
        if (GridCourses.SelectedItem is not CourseRow row) { Msg.Info("ابتدا یک دوره را انتخاب کنید."); return; }
        try
        {
            var n = IssueForCourse(row.Id);
            Msg.Info($"{Fa(n)} گواهی جدید صادر شد. (فقط شرکت‌کنندگانِ «تکمیل دوره» گواهی می‌گیرند.)");
            LoadCourses(); LoadCerts(); LoadDashboard();
        }
        catch (Exception ex) { Msg.Error("صدور گواهی ناموفق بود:\n" + ex.Message); }
    }

    /// <summary>برای همه تکمیل‌کنندگان دوره که گواهی ندارند، گواهی صادر می‌کند.</summary>
    public static int IssueForCourse(int courseId)
    {
        int created = 0;
        using var db = new AppDb();
        var list = db.Enrollments.Include(e => e.Instructor).Include(e => e.Course)
            .Where(e => e.CourseId == courseId && e.Status == St.Completed).ToList();
        foreach (var en in list)
        {
            var (cert, isNew) = CertificateService.Issue(db, en);
            if (isNew)
            {
                created++;
                Audit.Log("صدور گواهی", $"{cert.Serial} — {cert.HolderName}");
            }
        }
        return created;
    }

    // ============================================================ گواهی‌ها
    private void LoadCerts()
    {
        using var db = new AppDb();
        var q = db.Certificates.AsQueryable();
        var t = Jalali.Norm(SearchCert.Text);
        if (t.Length > 0)
        {
            var code = Jalali.ToEn(t).ToUpperInvariant().Replace("-", "");
            var en = Jalali.ToEn(t);
            q = q.Where(c => c.Serial.Contains(en) || c.VerifyCode.Contains(code)
                             || c.HolderName.Contains(t) || c.CourseTitle.Contains(t));
        }
        GridCerts.ItemsSource = q.OrderByDescending(c => c.IssuedAt).ToList();
    }

    private void SearchCert_Changed(object sender, TextChangedEventArgs e)
    {
        if (_ready) LoadCerts();
    }

    private void OpenPdf(Certificate c)
    {
        if (c == null) { Msg.Info("ابتدا یک گواهی را انتخاب کنید."); return; }
        try
        {
            CertificateService.OpenPdf(c);
            Audit.Log("مشاهده PDF گواهی", c.Serial);
        }
        catch (Exception ex) { Msg.Error("ساخت PDF ناموفق بود:\n" + ex.Message); App.LogError(ex); }
    }

    private void OpenCert_Click(object sender, RoutedEventArgs e) => OpenPdf(GridCerts.SelectedItem as Certificate);

    private void SaveAllCerts_Click(object sender, RoutedEventArgs e)
    {
        var items = GridCerts.SelectedItems.Cast<Certificate>().ToList();
        if (items.Count == 0) { Msg.Info("گواهی‌ها را انتخاب کنید (Ctrl+A برای انتخاب همه)."); return; }
        var dlg = new OpenFolderDialog { Title = "پوشه مقصد" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            foreach (var c in items)
                File.WriteAllBytes(Path.Combine(dlg.FolderName, c.Serial + ".pdf"), PdfService.Render(c));
            Audit.Log("ذخیره گروهی PDF گواهی", $"{items.Count} مورد");
            Msg.Info($"{Fa(items.Count)} فایل PDF ذخیره شد.");
        }
        catch (Exception ex) { Msg.Error("ذخیره ناموفق بود:\n" + ex.Message); App.LogError(ex); }
    }

    private void Revoke_Click(object sender, RoutedEventArgs e)
    {
        var ids = GridCerts.SelectedItems.Cast<Certificate>().Where(c => c.IsValid).Select(c => c.Id).ToList();
        if (ids.Count == 0) { Msg.Info("گواهی معتبری انتخاب نشده است."); return; }
        if (!Msg.Confirm($"{Fa(ids.Count)} گواهی باطل شود؟ در استعلام «باطل‌شده» نمایش داده می‌شود.")) return;
        using (var db = new AppDb())
        {
            foreach (var c in db.Certificates.Where(x => ids.Contains(x.Id)).ToList())
            {
                c.Status = St.Revoked;
                c.RevokedAt = DateTime.Now;
                Audit.Log("ابطال گواهی", c.Serial);
            }
            db.SaveChanges();
        }
        LoadCerts(); LoadDashboard();
    }

    private void Restore_Click(object sender, RoutedEventArgs e)
    {
        var ids = GridCerts.SelectedItems.Cast<Certificate>().Where(c => !c.IsValid).Select(c => c.Id).ToList();
        if (ids.Count == 0) { Msg.Info("گواهی باطل‌شده‌ای انتخاب نشده است."); return; }
        using (var db = new AppDb())
        {
            foreach (var c in db.Certificates.Where(x => ids.Contains(x.Id)).ToList())
            {
                c.Status = St.Valid;
                c.RevokedAt = null;
                Audit.Log("بازگردانی اعتبار گواهی", c.Serial);
            }
            db.SaveChanges();
        }
        LoadCerts(); LoadDashboard();
    }

    // ============================================================ استعلام
    private void VerifyBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) Verify_Click(sender, e);
    }

    private void Verify_Click(object sender, RoutedEventArgs e)
    {
        var raw = Jalali.ToEn(VerifyBox.Text.Trim()).ToUpperInvariant();
        var code = new string(raw.Where(char.IsLetterOrDigit).ToArray());
        using var db = new AppDb();
        var serialKey = raw.Replace(" ", "");
        var c = db.Certificates.FirstOrDefault(x => x.VerifyCode == code || x.Serial == serialKey);

        VerifyResult.Visibility = Visibility.Visible;
        if (c == null)
        {
            VerifyResult.BorderBrush = new SolidColorBrush(Color.FromRgb(0xB3, 0x26, 0x1E));
            VerifyText.Text = "گواهی‌ای با این کد یا سریال پیدا نشد.";
        }
        else if (!c.IsValid)
        {
            VerifyResult.BorderBrush = new SolidColorBrush(Color.FromRgb(0xB3, 0x26, 0x1E));
            VerifyText.Text = $"✖ این گواهی باطل شده است.\nسریال: {c.Serial}";
        }
        else
        {
            VerifyResult.BorderBrush = new SolidColorBrush(Color.FromRgb(0x1D, 0x7A, 0x46));
            VerifyText.Text = $"✔ گواهی معتبر است.\n\nدارنده: {c.HolderName}\nدوره: {c.CourseTitle}\n" +
                              $"مدت: {Jalali.ToFa(c.CourseHours)} ساعت\nتاریخ برگزاری: {Jalali.ToFa(c.CourseDates)}\n" +
                              $"تاریخ صدور: {Jalali.ToFa(c.IssueDateText)}\nسریال: {c.Serial}\nکد رهگیری: {c.DisplayCode}";
        }
    }

    // ============================================================ رویدادها
    private void LoadLogs()
    {
        using var db = new AppDb();
        GridLogs.ItemsSource = db.AuditLogs.OrderByDescending(l => l.At).Take(500).ToList();
    }

    // ============================================================ تنظیمات
    private void LoadSettingsUi()
    {
        var s = SettingsStore.Current;
        SetOrg.Text = s.OrgName;
        SetOffice.Text = s.OfficeName;
        SetPrefix.Text = s.SerialPrefix;
        SetS1T.Text = s.Signer1Title;
        SetS1N.Text = s.Signer1Name;
        SetS2T.Text = s.Signer2Title;
        SetS2N.Text = s.Signer2Name;
        SetUrl.Text = s.BaseUrl;
        SetPort.Text = s.Port.ToString();
        SetServer.IsChecked = s.EnableServer;
        ServerStatus.Text = "وضعیت سرور استعلام: " + VerifyServer.Status;
    }

    private void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(Jalali.ToEn(SetPort.Text.Trim()), out var port) || port < 1024 || port > 65535)
        { Msg.Error("پورت باید عددی بین ۱۰۲۴ تا ۶۵۵۳۵ باشد."); return; }
        if (!Uri.TryCreate(SetUrl.Text.Trim(), UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
        { Msg.Error("آدرس استعلام باید با http:// یا https:// شروع شود."); return; }
        var prefix = SetPrefix.Text.Trim();
        if (prefix.Length == 0 || !prefix.All(ch => char.IsLetterOrDigit(ch) && ch < 128))
        { Msg.Error("پیشوند سریال فقط حروف انگلیسی و عدد باشد (مثلاً BUMS)."); return; }

        var s = new AppSettings
        {
            OrgName = SetOrg.Text.Trim(), OfficeName = SetOffice.Text.Trim(), SerialPrefix = prefix.ToUpperInvariant(),
            Signer1Title = SetS1T.Text.Trim(), Signer1Name = SetS1N.Text.Trim(),
            Signer2Title = SetS2T.Text.Trim(), Signer2Name = SetS2N.Text.Trim(),
            BaseUrl = uri.ToString().TrimEnd('/'), Port = port, EnableServer = SetServer.IsChecked == true,
        };
        SettingsStore.Save(s);
        Audit.Log("ذخیره تنظیمات");

        try
        {
            if (s.EnableServer) VerifyServer.Start(s.Port); else VerifyServer.Stop();
        }
        catch (Exception ex) { App.LogError(ex); Msg.Error("راه‌اندازی سرور استعلام ناموفق بود (شاید پورت در حال استفاده است):\n" + ex.Message); }

        LoadSettingsUi();
        RefreshAll();
        Msg.Info("تنظیمات ذخیره شد.");
    }

    private void Backup_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFolderDialog { Title = "پوشه ذخیره پشتیبان" };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            var file = Path.Combine(dlg.FolderName, $"ftcms-backup-{DateTime.Now:yyyyMMdd-HHmm}.db");
            using (var db = new AppDb())
                db.Database.ExecuteSqlRaw($"VACUUM INTO '{file.Replace("'", "''")}'");
            if (File.Exists(Paths.SettingsFile))
                File.Copy(Paths.SettingsFile, Path.ChangeExtension(file, ".settings.json"), true);
            Audit.Log("پشتیبان‌گیری", file);
            Msg.Info("پشتیبان ذخیره شد:\n" + file);
        }
        catch (Exception ex) { Msg.Error("پشتیبان‌گیری ناموفق بود:\n" + ex.Message); }
    }

    private void OpenData_Click(object sender, RoutedEventArgs e) =>
        Process.Start(new ProcessStartInfo { FileName = Paths.Dir, UseShellExecute = true });
}
